#!/usr/bin/dumb-init /bin/sh

set -x

exec "$@"
